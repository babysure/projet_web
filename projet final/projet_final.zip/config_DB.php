<?php 
// la base de donnée doit être une base MySQL
define("NOM_BD", "agenda_projet_univ") ;
define("LOGIN_USER_BD" ,"root");
define("HOST_DB", "localhost");
define("MDP_USER_BD" , "") ;