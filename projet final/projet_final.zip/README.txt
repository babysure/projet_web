Instalation :
Aller dans le fichier config_DB.php
et remplacer les  constantes de configuration de Base de donnée ( HOST , nom de la base de donnée , login , mot de passe )

Note :  la couleur d'un évènements dépend du statut de cet évènement 